function performMath(num1, num2) {
    const addition = num1 + num2;
    const subtraction = num1 - num2;
    const multiplication = num1 * num2;
    const division = num1 / num2;

    const resultElement = document.getElementById('result');
    resultElement.innerHTML = `
        <strong>Math Results:</strong><br>
        Addition: ${addition} <br>
        Subtraction: ${subtraction} <br>
        Multiplication: ${multiplication} <br>
        Division: ${division.toFixed(2)} <br>
    `;
}

document.getElementById('trigger').addEventListener('click', function() {
    performMath(10, 5);
});

document.getElementById('colorButton').addEventListener('click', function() {
    const randomColor = getRandomColor();
    document.body.style.backgroundColor = randomColor;
});

function getRandomColor() {
    const letters = '0123456789ABCDEF';
    let color = '#';
    for (let i = 0; i < 6; i++) {
        color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
}

document.body.addEventListener('keypress', function(event) {
    const resultElement = document.getElementById('result');
    resultElement.innerHTML = `You pressed the '${event.key}' key!`;
});

